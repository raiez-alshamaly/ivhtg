import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  phoneNumber: text("phone_number"),
  telegramUsername: text("telegram_username").notNull(),
  telegramChatId: text("telegram_chat_id").notNull(),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0").notNull(),
  referralCode: text("referral_code").notNull(),
  referredBy: integer("referred_by").references(() => users.id),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  type: text("type", { enum: ["deposit", "withdrawal", "gift", "referral_bonus", "jackpot_win"] }).notNull(),
  method: text("method", { 
    enum: ["crypto", "bemo", "albaraka", "syriatel", "mtn"] 
  }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status", { enum: ["pending", "approved", "rejected"] }).notNull(),
  referenceNumber: text("reference_number").notNull(),
  details: text("details"), 
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const bets = pgTable("bets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  odds: decimal("odds", { precision: 5, scale: 2 }).notNull(),
  status: text("status", { enum: ["pending", "won", "lost"] }).notNull(),
  gameType: text("game_type").notNull(),
  payout: decimal("payout", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const giftCodes = pgTable("gift_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  isUsed: boolean("is_used").default(false).notNull(),
  usedBy: integer("used_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at")
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const vpnSubscriptions = pgTable("vpn_subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  status: text("status", { enum: ["active", "expired"] }).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Schemas for data insertion
export const insertUserSchema = createInsertSchema(users)
  .pick({
    username: true,
    password: true,
    phoneNumber: true,
    telegramUsername: true
  })
  .extend({
    password: z.string().min(8, "Password must be at least 8 characters"),
    telegramUsername: z.string().min(1, "Telegram username is required")
  });

export const insertTransactionSchema = createInsertSchema(transactions)
  .pick({
    type: true,
    method: true,
    amount: true,
    referenceNumber: true,
    details: true
  })
  .extend({
    amount: z.number().positive("Amount must be positive"),
    referenceNumber: z.string().min(1, "Reference number is required"),
    details: z.string().optional()
  });

export const insertBetSchema = createInsertSchema(bets)
  .pick({
    amount: true,
    odds: true,
    gameType: true
  })
  .extend({
    amount: z.number().positive("Amount must be positive"),
    odds: z.number().positive("Odds must be positive")
  });

export const insertGiftCodeSchema = createInsertSchema(giftCodes)
  .pick({
    code: true,
    amount: true,
    expiresAt: true
  });

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Bet = typeof bets.$inferSelect;
export type GiftCode = typeof giftCodes.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type VPNSubscription = typeof vpnSubscriptions.$inferSelect;