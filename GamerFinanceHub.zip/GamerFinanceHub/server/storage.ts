import { IStorage } from "./types";
import { User, Transaction, Message, InsertUser } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { randomBytes, scryptSync } from "crypto";

const MemoryStore = createMemoryStore(session);

function generateInitialPasswordHash(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const buf = scryptSync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private transactions: Map<number, Transaction>;
  private messages: Map<number, Message>;
  sessionStore: session.Store;
  currentId: { [key: string]: number };

  constructor() {
    this.users = new Map();
    this.transactions = new Map();
    this.messages = new Map();
    this.currentId = { users: 1, transactions: 1, messages: 1 };
    this.sessionStore = new MemoryStore({ checkPeriod: 86400000 });

    // Create default admin account
    const adminUser: User = {
      id: this.currentId.users++,
      username: "admin",
      password: generateInitialPasswordHash("admin"),
      phoneNumber: null,
      telegramUsername: "admin",
      telegramChatId: "admin",
      balance: "0",
      referralCode: randomBytes(8).toString('hex'),
      referredBy: null,
      isAdmin: true,
      createdAt: new Date()
    };
    this.users.set(adminUser.id, adminUser);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = {
      ...insertUser,
      id,
      balance: "0",
      referralCode: randomBytes(8).toString('hex'),
      referredBy: null,
      isAdmin: false,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((tx) => tx.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getPendingTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((tx) => tx.status === "pending")
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createTransaction(
    userId: number,
    type: "deposit" | "withdrawal" | "gift" | "referral_bonus" | "jackpot_win",
    method: "crypto" | "bemo" | "albaraka" | "syriatel" | "mtn",
    amount: number,
    referenceNumber: string,
    details?: string
  ): Promise<Transaction> {
    const id = this.currentId.transactions++;
    const transaction: Transaction = {
      id,
      userId,
      type,
      method,
      amount: amount.toString(),
      status: "pending",
      referenceNumber,
      details: details || null,
      createdAt: new Date()
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransactionStatus(
    id: number,
    status: "approved" | "rejected"
  ): Promise<Transaction> {
    const transaction = this.transactions.get(id);
    if (!transaction) throw new Error("Transaction not found");

    const updatedTransaction = { ...transaction, status };
    this.transactions.set(id, updatedTransaction);

    if (status === "approved") {
      const user = this.users.get(transaction.userId);
      if (!user) throw new Error("User not found");

      const currentBalance = parseFloat(user.balance);
      const transactionAmount = parseFloat(transaction.amount);

      const updatedUser = {
        ...user,
        balance: (transaction.type === "deposit"
          ? currentBalance + transactionAmount
          : currentBalance - transactionAmount).toString()
      };
      this.users.set(user.id, updatedUser);
    }

    return updatedTransaction;
  }

  async createMessage(userId: number, content: string): Promise<Message> {
    const id = this.currentId.messages++;
    const message: Message = {
      id,
      userId,
      content,
      isRead: false,
      createdAt: new Date()
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessages(userId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((msg) => msg.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();