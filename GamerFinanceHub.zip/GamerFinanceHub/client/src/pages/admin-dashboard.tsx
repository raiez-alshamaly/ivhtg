import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Transaction, User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Redirect } from "wouter";

export default function AdminDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Redirect non-admin users
  if (!user?.isAdmin) {
    return <Redirect to="/" />;
  }

  const { data: transactions, isLoading: loadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions/pending"],
  });

  const { data: users, isLoading: loadingUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const handleUpdateStatus = async (id: number, status: "approved" | "rejected") => {
    try {
      await apiRequest("PATCH", `/api/transactions/${id}`, { status });
      await queryClient.invalidateQueries({ queryKey: ["/api/transactions/pending"] });
      toast({
        title: `Transaction ${status}`,
        description: `تم ${status === "approved" ? "قبول" : "رفض"} المعاملة بنجاح`,
      });
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  if (loadingTransactions || loadingUsers) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">لوحة التحكم</h1>

      <Tabs defaultValue="transactions">
        <TabsList className="w-full">
          <TabsTrigger value="transactions">المعاملات المعلقة</TabsTrigger>
          <TabsTrigger value="users">إدارة المستخدمين</TabsTrigger>
        </TabsList>

        <TabsContent value="transactions" className="mt-6">
          <div className="rounded-lg border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المعرف</TableHead>
                  <TableHead>المستخدم</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>الطريقة</TableHead>
                  <TableHead>المبلغ</TableHead>
                  <TableHead>رقم المعاملة</TableHead>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions?.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{transaction.id}</TableCell>
                    <TableCell>{transaction.userId}</TableCell>
                    <TableCell className="capitalize">
                      {transaction.type === "deposit" ? "إيداع" :
                       transaction.type === "withdrawal" ? "سحب" :
                       transaction.type === "gift" ? "هدية" :
                       transaction.type === "referral_bonus" ? "مكافأة إحالة" : "ربح جاكبوت"}
                    </TableCell>
                    <TableCell className="capitalize">{transaction.method}</TableCell>
                    <TableCell>${parseFloat(transaction.amount).toFixed(2)}</TableCell>
                    <TableCell>{transaction.referenceNumber}</TableCell>
                    <TableCell>
                      {new Date(transaction.createdAt).toLocaleString('ar-SA')}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-green-500/10 hover:bg-green-500/20"
                          onClick={() => handleUpdateStatus(transaction.id, "approved")}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-red-500/10 hover:bg-red-500/20"
                          onClick={() => handleUpdateStatus(transaction.id, "rejected")}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!transactions || transactions.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      لا توجد معاملات معلقة
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="users" className="mt-6">
          <div className="rounded-lg border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المعرف</TableHead>
                  <TableHead>اسم المستخدم</TableHead>
                  <TableHead>رقم الهاتف</TableHead>
                  <TableHead>معرف التلغرام</TableHead>
                  <TableHead>الرصيد</TableHead>
                  <TableHead>تاريخ التسجيل</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users?.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>{user.id}</TableCell>
                    <TableCell>{user.username}</TableCell>
                    <TableCell>{user.phoneNumber || "-"}</TableCell>
                    <TableCell>{user.telegramUsername}</TableCell>
                    <TableCell>${parseFloat(user.balance).toFixed(2)}</TableCell>
                    <TableCell>
                      {new Date(user.createdAt).toLocaleString('ar-SA')}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}