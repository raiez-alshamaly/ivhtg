import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Transaction, Bet } from "@shared/schema";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Wallet, Gift, Users, MessageSquare, History, Trophy, Shield, Download, FileText, Settings, LogOut } from "lucide-react";
import { TransactionHistory } from "@/components/transactions/transaction-history";
import { TransactionForm } from "@/components/transactions/transaction-form";
import { BetHistory } from "@/components/bets/bet-history";
import { Link } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function Dashboard() {
  const { user, logoutMutation } = useAuth();

  const { data: transactions, isLoading: loadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  if (loadingTransactions) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">مرحباً, {user?.username}!</h1>
        <p className="text-xl font-medium text-muted-foreground mb-2">
          رصيدك الحالي: ${parseFloat(user?.balance || "0").toFixed(2)}
        </p>
        {!user?.telegramChatId && (
          <p className="text-sm text-yellow-600">
            لم يتم ربط حسابك مع تيليجرام بعد. قم بزيارة @gaming_hub_bot وأرسل /start للربط.
          </p>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>القائمة الرئيسية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {user?.isAdmin && (
                <Link href="/admin">
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="h-5 w-5 mr-2" />
                    لوحة التحكم
                  </Button>
                </Link>
              )}

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <Wallet className="h-5 w-5 mr-2" />
                    سحب رصيد
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>سحب رصيد</DialogTitle>
                  </DialogHeader>
                  <TransactionForm defaultType="withdrawal" />
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <Wallet className="h-5 w-5 mr-2" />
                    شحن رصيد
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>شحن رصيد</DialogTitle>
                  </DialogHeader>
                  <TransactionForm defaultType="deposit" />
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="h-5 w-5 mr-2" />
                    نظام الإحالات (رمز الإحالة: {user?.referralCode})
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>نظام الإحالات</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p>قم بدعوة أصدقائك واحصل على مكافآت!</p>
                    <p>رمز الإحالة الخاص بك: <strong>{user?.referralCode}</strong></p>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <Gift className="h-5 w-5 mr-2" />
                    إهداء رصيد
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>إهداء رصيد</DialogTitle>
                  </DialogHeader>
                  <TransactionForm defaultType="gift" />
                </DialogContent>
              </Dialog>

              <Button variant="outline" className="w-full justify-start">
                <Gift className="h-5 w-5 mr-2" />
                كود هدية
              </Button>

              <Button variant="outline" className="w-full justify-start">
                <MessageSquare className="h-5 w-5 mr-2" />
                تواصل معنا
              </Button>

              <Button variant="outline" className="w-full justify-start">
                <MessageSquare className="h-5 w-5 mr-2" />
                رسالة للأدمين
              </Button>

              <Button variant="outline" className="w-full justify-start">
                <FileText className="h-5 w-5 mr-2" />
                الشروحات
              </Button>

              <Button variant="outline" className="w-full justify-start">
                <Trophy className="h-5 w-5 mr-2" />
                الجَاكبوت
              </Button>

              <Button variant="outline" className="w-full justify-start">
                <Shield className="h-5 w-5 mr-2" />
                تطبيق VPN
              </Button>

              <Button variant="outline" className="w-full justify-start">
                <Download className="h-5 w-5 mr-2" />
                تحميل تطبيق ichancy
              </Button>

              <Button variant="outline" className="w-full justify-start">
                <FileText className="h-5 w-5 mr-2" />
                الشروط والأحكام
              </Button>

              <Button 
                variant="outline" 
                className="w-full justify-start text-red-500 hover:text-red-600"
                onClick={() => logoutMutation.mutate()}
              >
                <LogOut className="h-5 w-5 mr-2" />
                تسجيل الخروج
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="lg:col-span-3 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TransactionHistory />
            <BetHistory />
          </div>
        </div>
      </div>
    </div>
  );
}