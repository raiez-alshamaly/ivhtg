import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTransactionSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

interface TransactionFormProps {
  defaultType?: "deposit" | "withdrawal" | "gift";
}

export function TransactionForm({ defaultType = "deposit" }: TransactionFormProps) {
  const { toast } = useToast();
  const { user } = useAuth();

  const form = useForm({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      type: defaultType,
      method: defaultType === "gift" ? "internal" : "crypto",
      amount: 0,
      referenceNumber: "",
      details: "",
    },
  });

  const createTransaction = useMutation({
    mutationFn: async (data: {
      type: string;
      method: string;
      amount: number;
      referenceNumber: string;
      details?: string;
    }) => {
      const res = await apiRequest("POST", "/api/transactions", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({ title: "تم إنشاء المعاملة بنجاح" });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "فشل في إنشاء المعاملة",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit((data) => createTransaction.mutate(data))}
        className="space-y-6"
      >
        {defaultType !== "gift" && (
          <FormField
            control={form.control}
            name="method"
            render={({ field }) => (
              <FormItem>
                <FormLabel>طريقة الدفع</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر طريقة الدفع" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="crypto">عملات رقمية</SelectItem>
                    <SelectItem value="bemo">بنك بيمو</SelectItem>
                    <SelectItem value="albaraka">بنك البركة</SelectItem>
                    <SelectItem value="syriatel">سيرياتيل كاش</SelectItem>
                    <SelectItem value="mtn">MTN كاش</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>المبلغ</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="أدخل المبلغ"
                  {...field}
                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {defaultType === "gift" ? (
          <FormField
            control={form.control}
            name="referenceNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>اسم المستخدم المستلم</FormLabel>
                <FormControl>
                  <Input
                    placeholder="أدخل اسم المستخدم"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        ) : (
          <FormField
            control={form.control}
            name="referenceNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>رقم المعاملة</FormLabel>
                <FormControl>
                  <Input
                    placeholder="أدخل رقم المعاملة"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        {defaultType !== "gift" && (
          <FormField
            control={form.control}
            name="details"
            render={({ field }) => (
              <FormItem>
                <FormLabel>التفاصيل</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder={
                      field.value === "crypto"
                        ? "عنوان المحفظة..."
                        : field.value === "bemo" || field.value === "albaraka"
                        ? "رقم الحساب البنكي..."
                        : "رقم الهاتف..."
                    }
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        <Button
          type="submit"
          className="w-full"
          disabled={createTransaction.isPending}
        >
          {defaultType === "deposit" ? "إيداع" : 
           defaultType === "withdrawal" ? "سحب" : "إرسال"}
        </Button>
      </form>
    </Form>
  );
}