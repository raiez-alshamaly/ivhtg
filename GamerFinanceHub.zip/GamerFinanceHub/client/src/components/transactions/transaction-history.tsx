import { useQuery } from "@tanstack/react-query";
import { Transaction } from "@shared/schema";
import { Loader2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function TransactionHistory() {
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const formatAmount = (amount: string) => {
    return parseFloat(amount).toFixed(2);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>سجل المعاملات</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>النوع</TableHead>
              <TableHead>المبلغ</TableHead>
              <TableHead>الحالة</TableHead>
              <TableHead>التاريخ</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions?.map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell className="capitalize font-medium">
                  {transaction.type === "deposit" ? "إيداع" :
                   transaction.type === "withdrawal" ? "سحب" :
                   transaction.type === "gift" ? "هدية" :
                   transaction.type === "referral_bonus" ? "مكافأة إحالة" : "ربح جاكبوت"}
                </TableCell>
                <TableCell
                  className={
                    transaction.type === "deposit" || transaction.type === "win"
                      ? "text-green-600"
                      : "text-red-600"
                  }
                >
                  {transaction.type === "deposit" || transaction.type === "win"
                    ? "+"
                    : "-"}
                  ${formatAmount(transaction.amount)}
                </TableCell>
                <TableCell>
                  <span
                    className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium
                      ${
                        transaction.status === "approved"
                          ? "bg-green-50 text-green-700"
                          : transaction.status === "rejected"
                          ? "bg-red-50 text-red-700"
                          : "bg-yellow-50 text-yellow-700"
                      }
                    `}
                  >
                    {transaction.status === "approved" ? "تمت الموافقة" :
                     transaction.status === "rejected" ? "مرفوض" : "قيد الانتظار"}
                  </span>
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {new Date(transaction.createdAt).toLocaleString('ar-SA')}
                </TableCell>
              </TableRow>
            ))}
            {(!transactions || transactions.length === 0) && (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8">
                  لا توجد معاملات حتى الآن
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}