import { useQuery } from "@tanstack/react-query";
import { Bet } from "@shared/schema";
import { Loader2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function BetHistory() {
  const { data: bets, isLoading } = useQuery<Bet[]>({
    queryKey: ["/api/bets"],
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const formatAmount = (amount: string) => {
    return parseFloat(amount).toFixed(2);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>سجل الرهانات</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>نوع اللعبة</TableHead>
              <TableHead>المبلغ</TableHead>
              <TableHead>الاحتمالات</TableHead>
              <TableHead>الحالة</TableHead>
              <TableHead>المكسب</TableHead>
              <TableHead>التاريخ</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {bets?.map((bet) => (
              <TableRow key={bet.id}>
                <TableCell className="capitalize font-medium">
                  {bet.gameType}
                </TableCell>
                <TableCell>${formatAmount(bet.amount)}</TableCell>
                <TableCell>{bet.odds}x</TableCell>
                <TableCell>
                  <span
                    className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium
                      ${
                        bet.status === "won"
                          ? "bg-green-50 text-green-700"
                          : bet.status === "lost"
                          ? "bg-red-50 text-red-700"
                          : "bg-yellow-50 text-yellow-700"
                      }
                    `}
                  >
                    {bet.status === "won" ? "ربح" :
                     bet.status === "lost" ? "خسارة" : "قيد الانتظار"}
                  </span>
                </TableCell>
                <TableCell className={bet.status === "won" ? "text-green-600" : ""}>
                  {bet.payout ? `$${formatAmount(bet.payout)}` : "-"}
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {new Date(bet.createdAt).toLocaleString('ar-SA')}
                </TableCell>
              </TableRow>
            ))}
            {(!bets || bets.length === 0) && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  لا توجد رهانات حتى الآن
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
